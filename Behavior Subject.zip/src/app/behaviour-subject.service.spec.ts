import { TestBed, inject } from '@angular/core/testing';

import { BehaviourSubjectService } from './behaviour-subject.service';

describe('BehaviourSubjectService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BehaviourSubjectService]
    });
  });

  it('should be created', inject([BehaviourSubjectService], (service: BehaviourSubjectService) => {
    expect(service).toBeTruthy();
  }));
});
