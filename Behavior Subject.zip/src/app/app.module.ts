import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BehaviourSubjectService } from './behaviour-subject.service';


import { AppComponent } from './app.component';
import { TestcomponentComponent } from './testcomponent/testcomponent.component';
import {HttpClientModule} from '@angular/common/http';
import { Testcomponent1Component } from './testcomponent1/testcomponent1.component';
import { FormsModule } from '@angular/forms';
import { Testcomponent3Component } from './testcomponent3/testcomponent3.component';


@NgModule({
  declarations: [
    AppComponent,
    TestcomponentComponent,
    Testcomponent1Component,
    Testcomponent3Component,
   
  ],
  imports: [
    BrowserModule, HttpClientModule , FormsModule
  ],
  providers: [BehaviourSubjectService],
  bootstrap: [AppComponent]
})
export class AppModule { }
