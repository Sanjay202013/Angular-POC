import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  name: string;
  age : number;
  found : boolean = false;
  message : string;

  constructor (private httpClient: HttpClient){}

  keyChange(event:any){
    //console.log(event.target.value);
    this.name = event.target.value;
  }

  getProfile(){
    console.log("On Button click:" + this.name);

    this.httpClient.get(`https://my-json-server.typicode.com/techsithgit/json-faker-directory/profiles/?name=${this.name}`)
    .subscribe(
      (data: any []) => {
        console.log(data.length);
        if(data.length){
            this.age = data[0].age;
            this.found = true;
        }else if(data.length < 1) {
            this.found = false;
            this.message = "The user specified doesn't have any matches associated."
        }
      } 
    )

  }

}
