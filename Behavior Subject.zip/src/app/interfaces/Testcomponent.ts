export interface Testcomponent {
    serialNo : number;
    name : string;
    rollNumber : string;
}