import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testcomponent3',
  templateUrl: './testcomponent3.component.html',
  styleUrls: ['./testcomponent3.component.css']
})
export class Testcomponent3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
