import { Component, OnInit } from '@angular/core';
import { BehaviourSubjectService } from '../behaviour-subject.service';

@Component({
  selector: 'app-testcomponent1',
  templateUrl: './testcomponent1.component.html',
  styleUrls: ['./testcomponent1.component.css']
})
export class Testcomponent1Component implements OnInit {

  user:string;
  
  constructor(private behaviorSubject : BehaviourSubjectService) { }

  ngOnInit() {
    this.behaviorSubject.cast.subscribe(user => this.user = user);
  }

}
