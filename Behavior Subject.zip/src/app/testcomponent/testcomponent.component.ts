import { Component, OnInit } from '@angular/core';
import { Testcomponent } from '../interfaces/Testcomponent';
import { BehaviourSubjectService } from '../behaviour-subject.service';

@Component({
  selector: 'app-testcomponent',
  templateUrl: './testcomponent.component.html',
  styleUrls: ['./testcomponent.component.css']
})
export class TestcomponentComponent implements OnInit {

  testcomponent:Testcomponent;
  user:string;
  editUser:string;
  
  constructor(private behaviorService :BehaviourSubjectService) { }

  ngOnInit() {


    this.behaviorService.cast.subscribe(user => this.user = user);


    this.testcomponent = {
      serialNo : 50,
      name : "testIinterface",
      rollNumber : "A12345"
    }
  }

  changeUser(){
    this.behaviorService.editUser(this.editUser);
  }

}
