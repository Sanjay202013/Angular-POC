import { Component, OnInit, Input } from '@angular/core';
import { Router, ParamMap, ActivatedRoute } from '@angular/router'

@Component({
  selector: 'app-route4',
  templateUrl: './route4.component.html',
  styleUrls: ['./route4.component.css']
})
export class Route4Component implements OnInit {

  @Input() chocolateCount : string;
  receivedChildMessage: string;
  test :string;
  
  constructor(private route : ActivatedRoute, private router: Router){}

  ngOnInit() {

    
  }
}
  

