import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';


import { AppComponent } from './app.component';
import {Route1Component} from './route1/route1.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { Route2Component } from './route2/route2.component';
import { Route3Component } from './route3/route3.component';
import { Route4Component } from './route4/route4.component';
import { Route5Component } from './route5/route5.component';

const appRoutes: Routes = [
  { 
    path: 'route2/:id', 
    component: Route2Component 
  },

  { 
    path: 'route2', 
    component: Route2Component 
  },

  {
    path: 'route1',
    component: Route1Component,
    data: { title: 'Parent Route' }
  },

  {
    path: 'route3',
    component: Route3Component
  },

  {
    path: 'route4',
    component: Route4Component
  },

  { path: '',
    redirectTo: '/route1',
    pathMatch: 'full'
  },
  { path: '**', component: PageNotFoundComponent }
];


@NgModule({
  declarations: [
    AppComponent,
    Route1Component,
    PageNotFoundComponent,
    Route2Component,
    Route3Component,
    Route4Component,
    Route5Component
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
