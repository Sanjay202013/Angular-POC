import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute,  Router, NavigationExtras } from '@angular/router';


@Component({
  selector: 'app-route3',
  templateUrl: './route3.component.html',
  styleUrls: ['./route3.component.css']
})
export class Route3Component implements OnInit {

  constructor(private route : ActivatedRoute,private router: Router){} 
  
  @Output() messageToEmit = new EventEmitter<string>();
  model: any = {};

  //messageToRoute4 : string =  "This is the child page";

  ngOnInit() {
  }

  sendMessageToRoute4(message :  string){
    this.messageToEmit.emit("This is the child page");
  }

  chocolate = 0;  
    sendToChild() { 
      this.chocolate++; 
  }

  onSubmit(){
    let navigationExtras: NavigationExtras;
    let NavigationExtras = {state: {example: 'This is an example'}};
    this.router.navigate(['/route4',NavigationExtras]);
  }

}
