import { Component, OnInit, Input } from '@angular/core';
import { Router, ParamMap, ActivatedRoute } from '@angular/router'

@Component({
  selector: 'app-route4',
  templateUrl: './route4.component.html',
  styleUrls: ['./route4.component.css']
})
export class Route4Component implements OnInit {

  @Input() chocolateCount : string;
  receivedChildMessage: string;
  test :string;
  
  constructor(private route : ActivatedRoute, private router: Router){}

  ngOnInit() {

      console.log("This is the start :  "  +  this.route.snapshot.params.id);

      this.route.paramMap.subscribe((params : ParamMap)=> {
        this.test = params.get('id');
        
        TODO:// getting the data through the ParamMap
        //console.log("This is the End "  + params.get('id'));
      })
    
  }
}
  

